package com.example.online_book_store_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
